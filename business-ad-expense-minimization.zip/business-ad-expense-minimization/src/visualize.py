"""
Exploratory plots used in the report.

Each function takes the cleaned dataframe and renders one figure. By default
the figures are saved to ``figures/`` so they can be committed or embedded in
the README; pass ``show=True`` to open them interactively instead.
"""

from __future__ import annotations

import os

import matplotlib

# Use a non-interactive backend when no display is available (e.g. CI / servers).
if not os.environ.get("DISPLAY"):
    matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
import seaborn as sns  # noqa: E402

FIGURE_DIR = "figures"


def _finish(fig, name: str, show: bool):
    if show:
        plt.show()
    else:
        os.makedirs(FIGURE_DIR, exist_ok=True)
        path = os.path.join(FIGURE_DIR, name)
        fig.savefig(path, bbox_inches="tight", dpi=120)
        print(f"saved {path}")
    plt.close(fig)


def conversions_vs_impressions(df: pd.DataFrame, show: bool = False):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].scatter(df["impressions"], df["total conversions"])
    axes[0].set_xlabel("impressions")
    axes[0].set_ylabel("total conversions")
    axes[1].scatter(df["impressions"], df["approved conversions"])
    axes[1].set_xlabel("impressions")
    axes[1].set_ylabel("approved conversions")
    fig.tight_layout()
    _finish(fig, "conversions_vs_impressions.png", show)


def roas_by_campaign(df: pd.DataFrame, show: bool = False):
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.barplot(
        x=df["company campaign ID"], y=df["roas"], hue=df["age"], ax=ax
    )
    ax.set_title("ROAS by campaign ID and age group")
    _finish(fig, "roas_by_campaign.png", show)


def spend_by_campaign(df: pd.DataFrame, show: bool = False):
    fig, ax = plt.subplots(figsize=(7, 4))
    grouped = df.groupby("company campaign ID")["spent"].mean()
    ax.bar(grouped.index.astype(str), grouped.values)
    ax.set_xlabel("company campaign ID")
    ax.set_ylabel("amount spent")
    ax.set_title("Average spend by campaign")
    _finish(fig, "spend_by_campaign.png", show)


def interest_by_demographics(df: pd.DataFrame, show: bool = False):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    age_interest = df.groupby("age")["interest"].mean()
    axes[0].bar(age_interest.index.astype(str), age_interest.values)
    axes[0].set_xlabel("age")
    axes[0].set_ylabel("interest")
    gender_interest = df.groupby("gender")["interest"].mean()
    axes[1].bar(gender_interest.index.astype(str), gender_interest.values)
    axes[1].set_xlabel("gender")
    axes[1].set_ylabel("interest")
    fig.tight_layout()
    _finish(fig, "interest_by_demographics.png", show)


def correlation_heatmap(df: pd.DataFrame, show: bool = False):
    cols = [
        "impressions",
        "clicks",
        "spent",
        "total conversions",
        "approved conversions",
    ]
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(df[cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
    ax.set_title("Correlation between key advertising metrics")
    _finish(fig, "correlation_heatmap.png", show)


def render_all(df: pd.DataFrame, show: bool = False):
    """Generate every figure used in the analysis."""
    conversions_vs_impressions(df, show)
    roas_by_campaign(df, show)
    spend_by_campaign(df, show)
    interest_by_demographics(df, show)
    correlation_heatmap(df, show)
