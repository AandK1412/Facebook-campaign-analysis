"""
Command-line entry point.

Examples
--------
Interactive (prompts for targets, mirrors the original report):

    python -m src.main --data data/sample_data.csv

Non-interactive (the example values from the report):

    python -m src.main --data data/sample_data.csv \
        --impressions 150000 --clicks 50 --conversions 10

Also generate all figures:

    python -m src.main --data data/sample_data.csv --plots
"""

from __future__ import annotations

import argparse

from src import data_loader, optimizer, visualize


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--data",
        default="data/sample_data.csv",
        help="Path to the cleaned campaign CSV.",
    )
    p.add_argument("--impressions", type=int, help="Minimum impressions target.")
    p.add_argument("--clicks", type=int, help="Minimum clicks target.")
    p.add_argument("--conversions", type=int, help="Minimum total-conversions target.")
    p.add_argument(
        "--plots",
        action="store_true",
        help="Render all analysis figures into the figures/ directory.",
    )
    p.add_argument(
        "--show",
        action="store_true",
        help="Display figures interactively instead of saving them.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    df = data_loader.load(args.data)

    # Targets: use CLI flags if all are supplied, otherwise prompt.
    if None not in (args.impressions, args.clicks, args.conversions):
        targets = {
            "impressions": args.impressions,
            "clicks": args.clicks,
            "total conversions": args.conversions,
        }
    else:
        targets = optimizer.prompt_for_targets(df)

    result = optimizer.solve(df, targets)

    print("\n" + "=" * 50)
    print(result.model)
    print("=" * 50)
    print(result)
    print("=" * 50 + "\n")

    if args.plots or args.show:
        visualize.render_all(df, show=args.show)


if __name__ == "__main__":
    main()
