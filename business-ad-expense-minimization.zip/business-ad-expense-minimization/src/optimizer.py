"""
Linear-programming optimizer for the ad-spend minimization problem.

The model decides how many "units" of advertising to buy under each campaign
ID so that total spend is minimized while still hitting minimum targets for
impressions, clicks and total conversions.

    minimize    sum_c  mean_spent[c] * x_c
    subject to  sum_c  mean_metric[c, m] * x_c  >=  target[m]   for each metric m
                x_c >= 0 and integer

where c ranges over the campaign IDs and m over the tracked metrics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import pandas as pd
from pulp import LpInteger, LpMinimize, LpProblem, LpStatus, LpVariable, value

# Campaigns analysed in the original report (India / China / USA respectively).
CAMPAIGN_IDS: List[int] = [916, 936, 1178]

# Metrics used to build the LP constraints, in the order targets are supplied.
METRICS: List[str] = ["impressions", "clicks", "total conversions"]

CAMPAIGN_COLUMN = "company campaign ID"
SPEND_COLUMN = "spent"


@dataclass
class OptimizationResult:
    """Container for the solved model."""

    status: str
    objective: float
    allocation: Dict[int, float]   # campaign id -> recommended units
    model: LpProblem

    def __str__(self) -> str:  # pragma: no cover - human readable summary
        lines = [
            f"Solver status : {self.status}",
            f"Minimum cost  : {self.objective:.2f} (units)",
            "Allocation:",
        ]
        for cid, qty in self.allocation.items():
            lines.append(f"  campaign {cid}: {qty:g}")
        return "\n".join(lines)


def campaign_means(
    df: pd.DataFrame,
    campaign_ids: List[int] = CAMPAIGN_IDS,
    metrics: List[str] = METRICS,
) -> Dict[int, List[float]]:
    """Average value of each metric for each campaign.

    Returns a dict mapping ``campaign_id -> [mean_metric_0, mean_metric_1, ...]``
    in the same order as ``metrics``.
    """
    means: Dict[int, List[float]] = {}
    for cid in campaign_ids:
        subset = df[df[CAMPAIGN_COLUMN] == cid]
        if subset.empty:
            raise ValueError(f"No rows found for campaign ID {cid}")
        means[cid] = [float(subset[m].mean()) for m in metrics]
    return means


def campaign_costs(
    df: pd.DataFrame,
    campaign_ids: List[int] = CAMPAIGN_IDS,
) -> Dict[int, float]:
    """Average amount spent for each campaign (the objective coefficients)."""
    return {
        cid: float(df.loc[df[CAMPAIGN_COLUMN] == cid, SPEND_COLUMN].mean())
        for cid in campaign_ids
    }


def average_targets(df: pd.DataFrame, metrics: List[str] = METRICS) -> Dict[str, float]:
    """Dataset-wide mean of each metric.

    Used as a sensible lower bound for the interactive prompts: the original
    project required the user-supplied target to be at least the dataset mean.
    """
    return {m: float(df[m].mean()) for m in metrics}


def solve(
    df: pd.DataFrame,
    targets: Dict[str, float],
    campaign_ids: List[int] = CAMPAIGN_IDS,
    metrics: List[str] = METRICS,
) -> OptimizationResult:
    """Build and solve the cost-minimization LP.

    Parameters
    ----------
    df:
        Cleaned campaign dataframe.
    targets:
        Minimum required value for each metric, e.g.
        ``{"impressions": 150000, "clicks": 50, "total conversions": 10}``.
    """
    means = campaign_means(df, campaign_ids, metrics)
    costs = campaign_costs(df, campaign_ids)

    problem = LpProblem("AD_Conversions", LpMinimize)

    # One non-negative integer decision variable per campaign.
    variables = {
        cid: LpVariable(f"ID_{cid}", lowBound=0, cat=LpInteger)
        for cid in campaign_ids
    }

    # Objective: minimize total spend.
    problem += (
        sum(costs[cid] * variables[cid] for cid in campaign_ids),
        "ObjectiveFunction",
    )

    # One constraint per metric: weighted contribution must meet the target.
    for i, metric in enumerate(metrics):
        problem += (
            sum(means[cid][i] * variables[cid] for cid in campaign_ids)
            >= targets[metric],
            f"min_{metric.replace(' ', '_')}",
        )

    problem.solve()

    allocation = {cid: variables[cid].varValue for cid in campaign_ids}
    return OptimizationResult(
        status=LpStatus[problem.status],
        objective=value(problem.objective),
        allocation=allocation,
        model=problem,
    )


def prompt_for_targets(df: pd.DataFrame, metrics: List[str] = METRICS) -> Dict[str, float]:
    """Interactively collect a target for each metric.

    Re-prompts until the entered value is at least the dataset mean for that
    metric (mirroring the validation in the original report).
    """
    bounds = average_targets(df, metrics)
    targets: Dict[str, float] = {}
    for metric in metrics:
        floor = bounds[metric]
        while True:
            raw = input(f"Enter the least value of {metric} you wish to obtain: ")
            try:
                value_in = int(raw)
            except ValueError:
                print("Please enter a whole number.")
                continue
            if value_in >= floor:
                targets[metric] = value_in
                break
            print(f"Value isn't in range (must be >= {floor:.0f}). Try again.")
    return targets
