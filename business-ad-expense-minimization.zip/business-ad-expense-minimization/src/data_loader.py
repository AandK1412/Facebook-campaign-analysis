"""
Data loading and preparation.

The analysis expects a CSV with the column names used throughout the project:

    ad_id, company campaign ID, facebook campaign ID, age, gender, interest,
    impressions, clicks, spent, total conversions, approved conversions,
    click through rate, cost per click, cost per conversion, roas

The public Kaggle "Sales Conversion Optimization" dataset
(https://www.kaggle.com/datasets/loveall/clicks-conversion-tracking) uses
different column names. ``from_kaggle_raw`` maps those to the names above and
derives the extra metrics. If you don't have the dataset, run
``make_sample_data.py`` to generate a synthetic one so the project runs
out of the box.
"""

from __future__ import annotations

import pandas as pd

REQUIRED_COLUMNS = [
    "company campaign ID",
    "impressions",
    "clicks",
    "spent",
    "total conversions",
    "approved conversions",
    "roas",
    "age",
    "gender",
    "interest",
]

# Mapping from the raw Kaggle column names to the names used in this project.
KAGGLE_RENAME = {
    "xyz_campaign_id": "company campaign ID",
    "fb_campaign_id": "facebook campaign ID",
    "Impressions": "impressions",
    "Clicks": "clicks",
    "Spent": "spent",
    "Total_Conversion": "total conversions",
    "Approved_Conversion": "approved conversions",
}


def load(path: str) -> pd.DataFrame:
    """Load an already-cleaned CSV and validate its columns."""
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            "Dataset is missing required columns: "
            + ", ".join(missing)
            + ".\nIf this is the raw Kaggle file, run prepare_data.py first."
        )
    return df


def add_derived_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """Add click through rate, cost per click and cost per conversion.

    Division-by-zero is handled by leaving the result as 0 where the
    denominator is 0.
    """
    df = df.copy()
    df["click through rate"] = (df["clicks"] / df["impressions"]).fillna(0)
    df["cost per click"] = (df["spent"] / df["clicks"]).replace(
        [float("inf"), float("-inf")], 0
    ).fillna(0)
    df["cost per conversion"] = (
        df["spent"] / df["total conversions"]
    ).replace([float("inf"), float("-inf")], 0).fillna(0)
    return df


def from_kaggle_raw(path: str, value_per_conversion: float = 5.0) -> pd.DataFrame:
    """Convert the raw Kaggle dataset into the project schema.

    ``roas`` (return on ad spend) is not present in the raw data, so it is
    estimated as ``approved conversions * value_per_conversion / spent``.
    Adjust ``value_per_conversion`` to match your assumed revenue per
    approved conversion.
    """
    raw = pd.read_csv(path)
    df = raw.rename(columns=KAGGLE_RENAME)
    df = add_derived_metrics(df)
    df["roas"] = (
        df["approved conversions"] * value_per_conversion / df["spent"]
    ).replace([float("inf"), float("-inf")], 0).fillna(0)
    return df
