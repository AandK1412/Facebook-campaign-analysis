# About the original project

This repository is a refactored, runnable version of the academic mini-project
**"Business Advertisement Expense Minimization"** submitted at SVKM's NMIMS
University, Mukesh Patel School of Technology Management & Engineering (MPSTME),
for the 2022–23 academic year.

**Authors:** Anrunya Patole (L046), Kshama Purohit (L049), Archita Rai (L050)

## What changed from the report's code

The original was a single linear script. This version keeps the same modelling
logic but is reorganized for clarity and reproducibility:

- Split into modules: data loading, optimization, visualization, CLI.
- Removed the hardcoded Windows path (`C:\sample data.csv`); the data path is
  now a command-line argument.
- Replaced the flag-based `intake()` input loop with a single validated prompt
  helper, and added a non-interactive mode (CLI flags) for reproducible runs.
- The optimizer now returns a structured result object instead of only
  printing, so it can be imported and tested.
- Plots save to a `figures/` directory by default (with an interactive
  `--show` option) and use a headless backend when no display is available.
- Added a synthetic data generator and a Kaggle-to-schema converter so the
  project runs without manual data wrangling.

## Original analysis summary

The model minimizes total ad spend subject to minimum impression, click and
conversion targets. Across both the sampled and full data, campaign **916**
(India) showed the highest return on ad spend, while campaign **1178** (USA)
had the highest spend but the weakest return — so the optimizer directs
investment toward campaign 916.
