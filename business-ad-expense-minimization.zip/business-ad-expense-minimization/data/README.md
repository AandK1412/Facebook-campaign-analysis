# Data

This project expects a CSV named `sample_data.csv` in this folder with the
following columns:

```
ad_id, company campaign ID, facebook campaign ID, age, gender, interest,
impressions, clicks, spent, total conversions, approved conversions,
click through rate, cost per click, cost per conversion, roas
```

## Option 1 — synthetic data (runs immediately)

From the project root:

```bash
python make_sample_data.py
```

This writes a synthetic `sample_data.csv` with three campaigns (916, 936, 1178)
shaped like the data in the report. It is **not** real data — use it only to
try the code.

## Option 2 — real Kaggle data

1. Download the **Sales Conversion Optimization** dataset:
   https://www.kaggle.com/datasets/loveall/clicks-conversion-tracking
   (the file is usually `KAG_conversion_data.csv`).
2. Convert it to the project schema:

   ```bash
   python prepare_data.py path/to/KAG_conversion_data.csv
   ```

   The raw data has no revenue column, so ROAS is *estimated* as
   `approved conversions * value_per_conversion / spent`. Tune the assumed
   value with `--value-per-conversion`.

Generated CSVs are git-ignored by default if you'd rather not commit them —
see `.gitignore`.
